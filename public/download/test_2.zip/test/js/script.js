(function (c, d, w) {
    const addCustomerLink = d.querySelector('#addCustomers');
    const addCustomerIcon = d.querySelector('.icon-list-add');
    const newCustomer = d.querySelector('.newCustomer');
    const acceptButton = d.querySelector('#acceptButton');
    const popupContainer = d.querySelector('.popup-container');
    const iconClose = d.querySelector('.icon-times');
    const footer = d.querySelector('.popup-footer');
    const searchButton = d.querySelector('.icon-search');
    const addCustomer = d.querySelector('#newCustomer');
    const username = d.querySelector('#username');
    const password = d.querySelector('#password');
    const password1 = d.querySelector('#password1');
    const customersTable = d.querySelector('#customersTable');
    const usersTable = d.querySelector('#usersTable');
    const toSearch = d.querySelector('#customerToSearch');
    const listCustomers = d.querySelector('#listCustomers');

    let search = (name, mode) => {
        if (mode === 'customer') {
            customersTable.innerHTML = '';
            footer.style.color = 'red';
            footer.innerHTML = 'No se han encontrado clientes';
        } else {
            usersTable.innerHTML = '';
            footer.style.color = 'red';
            footer.innerHTML = 'No se han encontrado usuarios';
        }
        setTimeout(function () {
            footer.innerHTML = '';
        }, 3000);
    }

    let addNewCustomer = () => {
        if (addCustomer.value === '' || username.value === '' || password.value === '' || password1.value === '') {
            addCustomer.focus();
            footer.style.color = 'red';
            footer.innerHTML = 'Datos incompletos';
            setTimeout(function () {
                footer.innerHTML = '';
                return false;
            }, 6000);
        } else {
            if (password.value !== password1.value) {
                footer.style.color = 'red';
                footer.innerHTML = 'Las claves no son iguales';
                password.focus();
                setTimeout(function () {
                    footer.innerHTML = '';
                    return false;
                }, 6000);
            } else {
                if (password.value.length < 5) {
                    footer.style.color = 'red';
                    footer.innerHTML = 'El tamaño de la clave debe ser superior a cuatro caracteres';
                    password.focus();
                    setTimeout(function () {
                        footer.innerHTML = '';
                        return false;
                    }, 6000);
                } else {
                    let allcontent = customersTable.innerHTML;
                    customersTable.innerHTML = '<tr><td>' + addCustomer.value.toUpperCase() + '</td><td><select>\n' +
                        '                                <option>' + username.value + '</option>\n' +
                        '             </select>\n' +
                        '</td></tr>' + allcontent;
                    customersTable.rows.item(0).style.backgroundColor = '#bff0ff';
                    footer.style.color = 'green';
                    footer.innerHTML = 'Nuevo cliente ' + addCustomer.value.toUpperCase() + ' añadido';
                    newCustomer.style.display = 'none';
                    setTimeout(function () {
                        footer.style.color = 'black';
                        footer.innerHTML = 'Total clientes: ' + parseInt(parseInt(customersTable.rows.length) - 1);
                        return true;
                    }, 4000);
                }
            }
        }
    }

    let addNewUser = () => {
        if (username.value === '' || password.value === '' || password1.value === '') {
            username.focus();
            footer.style.color = 'red';
            footer.innerHTML = 'Datos incompletos';
            setTimeout(function () {
                footer.innerHTML = '';
                return false;
            }, 6000);
        } else {
            if (password.value !== password1.value) {
                footer.style.color = 'red';
                footer.innerHTML = 'Las claves no son iguales';
                password.focus();
                setTimeout(function () {
                    footer.innerHTML = '';
                    return false;
                }, 6000);
            } else {
                if (password.value.length < 5) {
                    footer.style.color = 'red';
                    footer.innerHTML = 'El tamaño de la clave debe ser superior a cuatro caracteres';
                    password.focus();
                    setTimeout(function () {
                        footer.innerHTML = '';
                        return false;
                    }, 6000);
                } else {
                    let allcontent = usersTable.innerHTML;
                    usersTable.innerHTML = '<tr><td>' + username.value + '</td><td>' + listCustomers.options[listCustomers.selectedIndex].value + '</td></tr>' + allcontent;
                    usersTable.rows.item(0).style.backgroundColor = '#bff0ff';
                    footer.style.color = 'green';
                    footer.innerHTML = 'Nuevo usuario ' + username.value + ' añadido al cliente ' + listCustomers.options[listCustomers.selectedIndex].value;
                    newCustomer.style.display = 'none';
                    setTimeout(() => {
                        footer.style.color = 'black';
                        footer.innerHTML = 'Total clientes: ' + parseInt(parseInt(usersTable.rows.length) - 1);
                        return true;
                    }, 4000)
                }
            }
        }
    }

    iconClose.addEventListener('click', function () {
        popupContainer.style.display = 'none';
    });
    addCustomerLink.addEventListener('click', function (e) {
        e.preventDefault();
        if (newCustomer.style.display === 'block') {
            newCustomer.style.display = 'none';
        } else {
            newCustomer.style.display = 'block';
        }
    });
    addCustomerIcon.addEventListener('click', function (e) {
        e.preventDefault();
        if (newCustomer.style.display === 'block') {
            newCustomer.style.display = 'none';
        } else {
            newCustomer.style.display = 'block';
        }
    });
    acceptButton.addEventListener('click', function (e) {
        e.preventDefault();
        if (addCustomer) {
            if (addNewCustomer()) {
                newCustomer.style.display = 'none';
            }
        } else {
            if (addNewUser()) {
                newCustomer.style.display = 'none';
            }
        }
    });

    searchButton.addEventListener('click', function (e) {
        e.preventDefault();
        if (toSearch.value && toSearch.value !== '') {
            if (addCustomer) {
                search(toSearch.value, 'customer');
            } else {
                search(toSearch.value, 'user');
            }
        } else {
            toSearch.focus();
        }
    });

})(console.log, document, window);